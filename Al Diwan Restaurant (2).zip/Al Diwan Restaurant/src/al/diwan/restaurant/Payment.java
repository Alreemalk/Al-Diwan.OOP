
package al.diwan.restaurant;

// Payment Classes
public interface Payment {
    public abstract boolean authorized();
}
